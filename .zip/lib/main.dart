import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:shared_preferences/shared_preferences.dart';

/* ============================ نقطة البداية ============================ */

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('ar', null);
  Intl.defaultLocale = 'ar';
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'فاتورة سريعة',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.teal,
          brightness: Brightness.light,
        ),
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
          isDense: true,
        ),
      ),
      home: const InvoiceScreen(),
    );
  }
}

/* ============================ النماذج ============================ */

class InvoiceItem {
  String name;
  double qty;
  double price;

  InvoiceItem({required this.name, required this.qty, required this.price});

  double get total => qty * price;

  Map<String, dynamic> toJson() => {'name': name, 'qty': qty, 'price': price};

  factory InvoiceItem.fromJson(Map<String, dynamic> json) => InvoiceItem(
    name: json['name'] as String? ?? '',
    qty: (json['qty'] as num?)?.toDouble() ?? 0,
    price: (json['price'] as num?)?.toDouble() ?? 0,
  );
}

class Invoice {
  final String id;
  final String invoiceNumber;
  final String customer;
  final String date;
  final List<InvoiceItem> items;
  final double discount;
  final double taxRate;

  Invoice({
    required this.id,
    required this.invoiceNumber,
    required this.customer,
    required this.date,
    required this.items,
    this.discount = 0,
    this.taxRate = 0,
  });

  double get subtotal => items.fold(0.0, (sum, item) => sum + item.total);
  double get taxAmount => subtotal * (taxRate / 100);
  double get total => subtotal - discount + taxAmount;

  Map<String, dynamic> toJson() => {
    'id': id,
    'invoiceNumber': invoiceNumber,
    'customer': customer,
    'date': date,
    'items': items.map((e) => e.toJson()).toList(),
    'discount': discount,
    'taxRate': taxRate,
  };

  factory Invoice.fromJson(Map<String, dynamic> json) => Invoice(
    id: json['id'] as String? ?? '',
    invoiceNumber: json['invoiceNumber'] as String? ?? '',
    customer: json['customer'] as String? ?? '',
    date: json['date'] as String? ?? '',
    items: (json['items'] as List<dynamic>? ?? [])
        .map((e) => InvoiceItem.fromJson(e as Map<String, dynamic>))
        .toList(),
    discount: (json['discount'] as num?)?.toDouble() ?? 0,
    taxRate: (json['taxRate'] as num?)?.toDouble() ?? 0,
  );
}

/* ======================== التخزين المحلي ======================== */

class InvoiceStore {
  static const String _key = 'invoices_v1';

  static Future<List<Invoice>> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_key);
      if (raw == null || raw.isEmpty) return [];
      final decoded = jsonDecode(raw);
      if (decoded is! List) return [];
      return decoded
          .whereType<Map<String, dynamic>>()
          .map(Invoice.fromJson)
          .toList();
    } catch (e) {
      debugPrint('خطأ في تحميل الفواتير: $e');
      return [];
    }
  }

  static Future<void> saveAll(List<Invoice> invoices) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _key,
      jsonEncode(invoices.map((e) => e.toJson()).toList()),
    );
  }

  static Future<void> add(Invoice invoice) async {
    final list = await load();
    list.add(invoice);
    await saveAll(list);
  }

  static Future<void> delete(String id) async {
    final list = await load();
    list.removeWhere((inv) => inv.id == id);
    await saveAll(list);
  }

  static Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }
}

/* ======================== أدوات التنسيق ======================== */

final NumberFormat _currencyFormat = NumberFormat("#,##0.00", "en");
final DateFormat _dateFormat = DateFormat("yyyy/MM/dd", "ar");

String formatCurrency(double value) {
  try {
    return _currencyFormat.format(value);
  } catch (_) {
    return value.toStringAsFixed(2);
  }
}

String formatDate(DateTime dt) {
  try {
    return _dateFormat.format(dt);
  } catch (_) {
    return '${dt.year}-${dt.month.toString().padLeft(2, '0')}-'
        '${dt.day.toString().padLeft(2, '0')}';
  }
}

String _generateInvoiceNumber() {
  final ts = DateTime.now().millisecondsSinceEpoch.toString();
  return ts.length > 5 ? ts.substring(5) : ts;
}

/* ========================= شاشة الفاتورة ========================= */

class InvoiceScreen extends StatefulWidget {
  const InvoiceScreen({super.key});

  @override
  State<InvoiceScreen> createState() => _InvoiceScreenState();
}

class _InvoiceScreenState extends State<InvoiceScreen> {
  final _customerCtrl = TextEditingController();
  final _invoiceNumberCtrl = TextEditingController();
  final _discountCtrl = TextEditingController(text: '0');
  final _taxCtrl = TextEditingController(text: '0');

  final List<InvoiceItem> _items = [];
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _invoiceNumberCtrl.text = _generateInvoiceNumber();
    _discountCtrl.addListener(_onTotalsChanged);
    _taxCtrl.addListener(_onTotalsChanged);
  }

  @override
  void dispose() {
    _discountCtrl.removeListener(_onTotalsChanged);
    _taxCtrl.removeListener(_onTotalsChanged);
    _customerCtrl.dispose();
    _invoiceNumberCtrl.dispose();
    _discountCtrl.dispose();
    _taxCtrl.dispose();
    super.dispose();
  }

  void _onTotalsChanged() {
    if (mounted) setState(() {});
  }

  double get _subtotal => _items.fold(0.0, (sum, item) => sum + item.total);
  double get _discount => double.tryParse(_discountCtrl.text.trim()) ?? 0;
  double get _taxRate => double.tryParse(_taxCtrl.text.trim()) ?? 0;
  double get _taxAmount => _subtotal * (_taxRate / 100);
  double get _grandTotal => _subtotal - _discount + _taxAmount;

  String get _today => formatDate(DateTime.now());

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(msg),
        behavior: SnackBarBehavior.floating,
      ));
  }

  /* ------------------------- الأصناف ------------------------- */

  Future<InvoiceItem?> _showItemDialog({InvoiceItem? initial}) async {
    final nameCtrl = TextEditingController(text: initial?.name ?? '');
    final qtyCtrl = TextEditingController(text: initial?.qty.toString() ?? '1');
    final priceCtrl =
    TextEditingController(text: initial?.price.toString() ?? '');
    final formKey = GlobalKey<FormState>();

    final result = await showDialog<InvoiceItem>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(initial == null ? 'إضافة صنف' : 'تعديل صنف'),
        content: Form(
          key: formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: nameCtrl,
                  textInputAction: TextInputAction.next,
                  decoration: const InputDecoration(labelText: 'اسم الصنف'),
                  validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'أدخل اسم الصنف' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: qtyCtrl,
                  keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'الكمية'),
                  validator: (v) {
                    final n = double.tryParse(v?.trim() ?? '');
                    if (n == null || n <= 0) return 'كمية غير صحيحة';
                    return null;
                  },
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: priceCtrl,
                  keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'السعر'),
                  validator: (v) {
                    final n = double.tryParse(v?.trim() ?? '');
                    if (n == null || n < 0) return 'سعر غير صحيح';
                    return null;
                  },
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              if (formKey.currentState!.validate()) {
                Navigator.pop(
                  ctx,
                  InvoiceItem(
                    name: nameCtrl.text.trim(),
                    qty: double.parse(qtyCtrl.text.trim()),
                    price: double.parse(priceCtrl.text.trim()),
                  ),
                );
              }
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );

    // تأجيل تحرير الموارد إطار واحد لتجنب استخدام Controller أثناء إغلاق الحوار
    WidgetsBinding.instance.addPostFrameCallback((_) {
      nameCtrl.dispose();
      qtyCtrl.dispose();
      priceCtrl.dispose();
    });

    return result;
  }

  Future<void> _addItem() async {
    final item = await _showItemDialog();
    if (item != null && mounted) setState(() => _items.add(item));
  }

  Future<void> _editItem(int index) async {
    if (index < 0 || index >= _items.length) return;
    final updated = await _showItemDialog(initial: _items[index]);
    if (updated != null && mounted) setState(() => _items[index] = updated);
  }

  void _removeItem(int index) {
    if (index < 0 || index >= _items.length) return;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف الصنف'),
        content: const Text('هل أنت متأكد من حذف هذا الصنف؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              if (mounted) setState(() => _items.removeAt(index));
            },
            child: const Text('حذف'),
          ),
        ],
      ),
    );
  }

  /* ------------------------- الفاتورة ------------------------- */

  Invoice _currentInvoice() {
    final invoiceNumber = _invoiceNumberCtrl.text.trim().isEmpty
        ? _generateInvoiceNumber()
        : _invoiceNumberCtrl.text.trim();
    return Invoice(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      invoiceNumber: invoiceNumber,
      customer: _customerCtrl.text.trim().isEmpty
          ? 'عميل نقدي'
          : _customerCtrl.text.trim(),
      date: _today,
      items: List.of(_items),
      discount: _discount,
      taxRate: _taxRate,
    );
  }

  Future<void> _saveInvoice() async {
    if (_items.isEmpty) {
      _snack('أضف صنفاً واحداً على الأقل');
      return;
    }
    try {
      final invoice = _currentInvoice();
      await InvoiceStore.add(invoice);
      _snack('تم حفظ الفاتورة (${formatCurrency(invoice.total)})');
    } catch (e) {
      _snack('خطأ في الحفظ: $e');
    }
  }

  Future<void> _sharePdf() async {
    if (_items.isEmpty) {
      _snack('أضف صنفاً واحداً على الأقل');
      return;
    }
    setState(() => _busy = true);
    try {
      final invoice = _currentInvoice();
      final doc = await buildInvoicePdf(invoice);
      final bytes = await doc.save();
      await Printing.sharePdf(
        bytes: bytes,
        filename: 'invoice_${invoice.invoiceNumber}.pdf',
      );
    } catch (e) {
      _snack('تعذر إنشاء PDF: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _printPdf() async {
    if (_items.isEmpty) {
      _snack('أضف صنفاً واحداً على الأقل');
      return;
    }
    setState(() => _busy = true);
    try {
      final invoice = _currentInvoice();
      final doc = await buildInvoicePdf(invoice);
      await Printing.layoutPdf(
        onLayout: (_) => doc.save(),
        name: 'invoice_${invoice.invoiceNumber}.pdf',
      );
    } catch (e) {
      _snack('تعذر الطباعة: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _newInvoice() {
    setState(() {
      _customerCtrl.clear();
      _invoiceNumberCtrl.text = _generateInvoiceNumber();
      _discountCtrl.text = '0';
      _taxCtrl.text = '0';
      _items.clear();
    });
  }

  void _openSaved() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const SavedInvoicesScreen()),
    );
  }

  /* --------------------------- الواجهة --------------------------- */

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('فاتورة سريعة'),
        backgroundColor: theme.colorScheme.primaryContainer,
        actions: [
          IconButton(
            tooltip: 'فاتورة جديدة',
            onPressed: _newInvoice,
            icon: const Icon(Icons.note_add_outlined),
          ),
          IconButton(
            tooltip: 'الفواتير المحفوظة',
            onPressed: _openSaved,
            icon: const Icon(Icons.history),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _buildHeaderCard(),
                const SizedBox(height: 16),
                _buildItemsHeader(theme),
                const Divider(),
                if (_items.isEmpty)
                  _buildEmptyState(theme)
                else
                  ..._items.asMap().entries.map(
                        (e) => _itemTile(e.key, e.value),
                  ),
              ],
            ),
          ),
          _bottomBar(theme),
        ],
      ),
    );
  }

  Widget _buildHeaderCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            TextField(
              controller: _customerCtrl,
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(
                labelText: 'اسم العميل',
                prefixIcon: Icon(Icons.person_outline),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _invoiceNumberCtrl,
                    decoration:
                    const InputDecoration(labelText: 'رقم الفاتورة'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: InputDecorator(
                    decoration: const InputDecoration(labelText: 'التاريخ'),
                    child: Text(_today),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _discountCtrl,
                    keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                    decoration:
                    const InputDecoration(labelText: 'الخصم (مبلغ)'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: _taxCtrl,
                    keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                    decoration:
                    const InputDecoration(labelText: 'الضريبة (%)'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildItemsHeader(ThemeData theme) {
    return Row(
      children: [
        Text(
          'الأصناف',
          style: theme.textTheme.titleMedium
              ?.copyWith(fontWeight: FontWeight.bold),
        ),
        const Spacer(),
        Text('${_items.length} صنف'),
      ],
    );
  }

  Widget _buildEmptyState(ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 40),
      child: Center(
        child: Column(
          children: [
            Icon(
              Icons.receipt_long_outlined,
              size: 56,
              color: theme.colorScheme.outline,
            ),
            const SizedBox(height: 12),
            const Text('لا توجد أصناف بعد'),
            const SizedBox(height: 4),
            Text(
              'اضغط "إضافة" للبدء',
              style: TextStyle(color: theme.colorScheme.outline),
            ),
          ],
        ),
      ),
    );
  }

  Widget _itemTile(int index, InvoiceItem item) {
    final theme = Theme.of(context);
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: theme.colorScheme.primaryContainer,
          child: Text('${index + 1}'),
        ),
        title: Text(item.name),
        subtitle: Text(
          '${item.qty.toStringAsFixed(item.qty % 1 == 0 ? 0 : 2)} × '
              '${formatCurrency(item.price)}',
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              formatCurrency(item.total),
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: theme.colorScheme.primary,
              ),
            ),
            IconButton(
              tooltip: 'تعديل',
              icon: const Icon(Icons.edit_outlined),
              onPressed: () => _editItem(index),
            ),
            IconButton(
              tooltip: 'حذف',
              icon: const Icon(Icons.delete_outline),
              onPressed: () => _removeItem(index),
            ),
          ],
        ),
      ),
    );
  }

  Widget _bottomBar(ThemeData theme) {
    return Material(
      elevation: 8,
      color: theme.colorScheme.surface,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _summaryRow('المجموع الفرعي', _subtotal),
              if (_discount > 0) _summaryRow('الخصم', -_discount),
              if (_taxRate > 0)
                _summaryRow(
                    'الضريبة (${_taxRate.toStringAsFixed(1)}%)', _taxAmount),
              const Divider(),
              Row(
                children: [
                  const Text(
                    'الإجمالي:',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const Spacer(),
                  Text(
                    formatCurrency(_grandTotal),
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: theme.colorScheme.primary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _busy ? null : _addItem,
                      icon: const Icon(Icons.add),
                      label: const Text('إضافة'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _busy ? null : _saveInvoice,
                      icon: const Icon(Icons.save_outlined),
                      label: const Text('حفظ'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _busy ? null : _printPdf,
                      icon: _busy
                          ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                          : const Icon(Icons.print_outlined),
                      label: const Text('طباعة'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: _busy ? null : _sharePdf,
                  icon: const Icon(Icons.share_outlined),
                  label: const Text('مشاركة PDF'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _summaryRow(String label, double value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          Text(label),
          const Spacer(),
          Text(
            formatCurrency(value),
            style: const TextStyle(fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}

/* ====================== شاشة الفواتير المحفوظة ====================== */

class SavedInvoicesScreen extends StatefulWidget {
  const SavedInvoicesScreen({super.key});

  @override
  State<SavedInvoicesScreen> createState() => _SavedInvoicesScreenState();
}

class _SavedInvoicesScreenState extends State<SavedInvoicesScreen> {
  late Future<List<Invoice>> _future;
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _future = InvoiceStore.load();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  void _reload() => setState(() => _future = InvoiceStore.load());

  Future<void> _deleteAll() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف الكل'),
        content: const Text('هل أنت متأكد من حذف جميع الفواتير؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await InvoiceStore.clear();
      if (mounted) _reload();
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('الفواتير المحفوظة'),
        backgroundColor: theme.colorScheme.primaryContainer,
        actions: [
          IconButton(
            tooltip: 'حذف الكل',
            onPressed: _deleteAll,
            icon: const Icon(Icons.delete_sweep_outlined),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _searchCtrl,
              decoration: const InputDecoration(
                hintText: 'بحث برقم الفاتورة أو اسم العميل',
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: (_) => setState(() {}),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<Invoice>>(
              future: _future,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return Center(child: Text('خطأ: ${snapshot.error}'));
                }
                final all = snapshot.data ?? [];
                final query = _searchCtrl.text.trim().toLowerCase();
                final filtered = query.isEmpty
                    ? all
                    : all.where((inv) {
                  return inv.customer.toLowerCase().contains(query) ||
                      inv.invoiceNumber.toLowerCase().contains(query);
                }).toList();

                if (filtered.isEmpty) {
                  return const Center(child: Text('لا توجد فواتير مطابقة'));
                }

                final totalSum =
                filtered.fold(0.0, (sum, inv) => sum + inv.total);

                return Column(
                  children: [
                    Expanded(
                      child: ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        itemCount: filtered.length,
                        itemBuilder: (context, i) {
                          final inv = filtered[filtered.length - 1 - i];
                          return Card(
                            margin: const EdgeInsets.only(bottom: 8),
                            child: ListTile(
                              leading: const CircleAvatar(
                                child: Icon(Icons.receipt),
                              ),
                              title: Text(inv.customer),
                              subtitle: Text(
                                'رقم: ${inv.invoiceNumber} • ${inv.date} • '
                                    '${inv.items.length} صنف',
                              ),
                              trailing: Text(
                                formatCurrency(inv.total),
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: theme.colorScheme.primary,
                                ),
                              ),
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) =>
                                        InvoiceDetailScreen(invoice: inv),
                                  ),
                                ).then((_) => _reload());
                              },
                            ),
                          );
                        },
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.all(12),
                      color: theme.colorScheme.primaryContainer,
                      child: Row(
                        children: [
                          const Text(
                            'مجموع الفواتير:',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          const Spacer(),
                          Text(
                            formatCurrency(totalSum),
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

/* ====================== شاشة تفاصيل الفاتورة ====================== */

class InvoiceDetailScreen extends StatelessWidget {
  final Invoice invoice;

  const InvoiceDetailScreen({super.key, required this.invoice});

  Future<void> _sharePdf(BuildContext context) async {
    try {
      final doc = await buildInvoicePdf(invoice);
      final bytes = await doc.save();
      await Printing.sharePdf(
        bytes: bytes,
        filename: 'invoice_${invoice.invoiceNumber}.pdf',
      );
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذر المشاركة: $e')),
        );
      }
    }
  }

  Future<void> _printPdf(BuildContext context) async {
    try {
      final doc = await buildInvoicePdf(invoice);
      await Printing.layoutPdf(
        onLayout: (_) => doc.save(),
        name: 'invoice_${invoice.invoiceNumber}.pdf',
      );
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذر الطباعة: $e')),
        );
      }
    }
  }

  Future<void> _delete(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف الفاتورة'),
        content: const Text('هل أنت متأكد من حذف هذه الفاتورة؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await InvoiceStore.delete(invoice.id);
      if (context.mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('فاتورة ${invoice.invoiceNumber}'),
        backgroundColor: theme.colorScheme.primaryContainer,
        actions: [
          IconButton(
            tooltip: 'حذف',
            onPressed: () => _delete(context),
            icon: const Icon(Icons.delete_outline),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'العميل: ${invoice.customer}',
                    style: const TextStyle(fontSize: 16),
                  ),
                  const SizedBox(height: 4),
                  Text('التاريخ: ${invoice.date}'),
                  const SizedBox(height: 4),
                  Text('رقم الفاتورة: ${invoice.invoiceNumber}'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          ...invoice.items.map(
                (item) => Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                title: Text(item.name),
                subtitle: Text(
                  '${item.qty.toStringAsFixed(2)} × '
                      '${formatCurrency(item.price)}',
                ),
                trailing: Text(
                  formatCurrency(item.total),
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _row('المجموع الفرعي', invoice.subtotal),
                  if (invoice.discount > 0)
                    _row('الخصم', -invoice.discount),
                  if (invoice.taxRate > 0)
                    _row(
                      'الضريبة (${invoice.taxRate.toStringAsFixed(1)}%)',
                      invoice.taxAmount,
                    ),
                  const Divider(),
                  _row('الإجمالي', invoice.total, bold: true),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _sharePdf(context),
                  icon: const Icon(Icons.share_outlined),
                  label: const Text('مشاركة PDF'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () => _printPdf(context),
                  icon: const Icon(Icons.print_outlined),
                  label: const Text('طباعة'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _row(String label, double value, {bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text(
            label,
            style: TextStyle(
              fontWeight: bold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          const Spacer(),
          Text(
            formatCurrency(value),
            style: TextStyle(
              fontWeight: bold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}

/* ========================= توليد ملف PDF ========================= */

/// يُحمّل خط عربي مع محاولات متعددة.
Future<List<pw.Font>> _loadArabicFonts() async {
  // المحاولة 1: Cairo
  try {
    final regular = await PdfGoogleFonts.cairoRegular();
    final bold = await PdfGoogleFonts.cairoBold();
    return [regular, bold];
  } catch (e) {
    debugPrint('فشل تحميل Cairo: $e');
  }

  // المحاولة 2: Amiri
  try {
    final regular = await PdfGoogleFonts.amiriRegular();
    final bold = await PdfGoogleFonts.amiriBold();
    return [regular, bold];
  } catch (e) {
    debugPrint('فشل تحميل Amiri: $e');
  }

  // المحاولة 3: Tajawal
  try {
    final regular = await PdfGoogleFonts.tajawalRegular();
    final bold = await PdfGoogleFonts.tajawalBold();
    return [regular, bold];
  } catch (e) {
    debugPrint('فشل تحميل Tajawal: $e');
  }

  throw Exception(
    'تعذر تحميل أي خط عربي. تأكد من اتصالك بالإنترنت وحاول مرة أخرى.',
  );
}

Future<pw.Document> buildInvoicePdf(Invoice invoice) async {
  final fonts = await _loadArabicFonts();
  final regular = fonts[0];
  final bold = fonts[1];

  final doc = pw.Document();

  doc.addPage(
    pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      textDirection: pw.TextDirection.rtl,
      theme: pw.ThemeData.withFont(base: regular, bold: bold),
      build: (context) => [
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  'فاتورة',
                  style: pw.TextStyle(
                    fontSize: 28,
                    fontWeight: pw.FontWeight.bold,
                    color: PdfColors.teal800,
                  ),
                ),
                pw.SizedBox(height: 4),
                pw.Text('رقم الفاتورة: ${invoice.invoiceNumber}'),
                pw.Text('التاريخ: ${invoice.date}'),
              ],
            ),
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.end,
              children: [
                pw.Text(
                  'شركتي',
                  style: pw.TextStyle(
                    fontSize: 16,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
                pw.Text('العنوان: ...'),
                pw.Text('الهاتف: ...'),
              ],
            ),
          ],
        ),
        pw.SizedBox(height: 16),
        pw.Divider(color: PdfColors.teal300),
        pw.SizedBox(height: 8),
        pw.Text(
          'العميل: ${invoice.customer}',
          style: const pw.TextStyle(fontSize: 14),
        ),
        pw.SizedBox(height: 16),
        pw.Table(
          border: pw.TableBorder.all(color: PdfColors.grey400, width: .5),
          children: [
            pw.TableRow(
              decoration: const pw.BoxDecoration(color: PdfColors.teal100),
              children: [
                _cell('الصنف', bold: true),
                _cell('الكمية', bold: true),
                _cell('السعر', bold: true),
                _cell('الإجمالي', bold: true),
              ],
            ),
            ...invoice.items.map(
                  (item) => pw.TableRow(
                children: [
                  _cell(item.name),
                  _cell(item.qty.toStringAsFixed(2)),
                  _cell(formatCurrency(item.price)),
                  _cell(formatCurrency(item.total)),
                ],
              ),
            ),
          ],
        ),
        pw.SizedBox(height: 16),
        pw.Container(
          alignment: pw.Alignment.centerLeft,
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              pw.Text('المجموع الفرعي: ${formatCurrency(invoice.subtotal)}'),
              if (invoice.discount > 0)
                pw.Text('الخصم: -${formatCurrency(invoice.discount)}'),
              if (invoice.taxRate > 0)
                pw.Text(
                  'الضريبة (${invoice.taxRate.toStringAsFixed(1)}%): '
                      '${formatCurrency(invoice.taxAmount)}',
                ),
              pw.Divider(),
              pw.Text(
                'الإجمالي الكلي: ${formatCurrency(invoice.total)}',
                style: pw.TextStyle(
                  fontSize: 16,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
        pw.SizedBox(height: 24),
        pw.Center(
          child: pw.Text(
            'شكراً لتعاملكم معنا',
            style: const pw.TextStyle(
              fontSize: 11,
              color: PdfColors.grey700,
            ),
          ),
        ),
      ],
    ),
  );

  return doc;
}

pw.Widget _cell(String text, {bool bold = false}) => pw.Padding(
  padding: const pw.EdgeInsets.all(6),
  child: pw.Text(
    text,
    textAlign: pw.TextAlign.center,
    style: pw.TextStyle(
      fontSize: 11,
      fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal,
    ),
  ),
);